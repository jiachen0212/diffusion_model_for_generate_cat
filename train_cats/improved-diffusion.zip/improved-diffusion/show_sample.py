# coding=utf-8
import cv2
import os
import numpy as np 


sample_res = np.load('jiachen_iddpm/samples_3x64x64x3.npz')
for i in range(sample_res['arr_0'].shape[0]):
    sample_ = sample_res['arr_0'][i]
    cv2.imwrite('./sample_res/{}.jpg'.format(i+1), sample_)